﻿CREATE PROCEDURE SearchByNameForActivityCayegory
@search nvarchar(max)
AS
BEGIN
SELECT        id AS آیدی, CategoryName AS [نام دسته بندی], Info AS [جزئیات دسته بندی], RegDate AS [تاریخ ثبت]
FROM            dbo.ActivityCategories
WHERE        (DeleteStatus = 0) AND (CategoryName LIKE @search)
END
GO
