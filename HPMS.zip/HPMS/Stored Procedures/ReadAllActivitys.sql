﻿CREATE PROCEDURE ReadAllActivitys
AS
BEGIN
SELECT        dbo.Activities.id AS آیدی, dbo.Activities.Title AS [موضوع فعالیت], dbo.ActivityCategories.CategoryName AS [نام دسته بندی], dbo.Rooms.Number AS [شماره اتاق], dbo.Activities.RegDate AS [تاریخ ثبت], 
                         dbo.Users.Name AS [نام کاربر]
FROM            dbo.Activities INNER JOIN
                         dbo.Rooms ON dbo.Activities.Room_id = dbo.Rooms.id INNER JOIN
                         dbo.Users ON dbo.Activities.user_id = dbo.Users.id INNER JOIN
                         dbo.ActivityCategories ON dbo.Activities.Category_id = dbo.ActivityCategories.id
WHERE        (dbo.Activities.DeleteStatus = 0)
END
GO
